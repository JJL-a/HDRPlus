% �����������
clear; clc;
% ��ʼ��ʱ
overallStartTime = tic;

% modifyPaths();
% modifyPathsBack();

addpath('Filter', 'relF');
addpath('E:\1\post\paper\PRNU-sourcecode\CameraFingerprint\Filter');
% 
% % �豸�б�
% devices = {'A01_GioneeS55','A02_Huawei-P8', 'A03_Huawei-Honor9', 'A04_Huawei-P10', 'A05_Hwawie-MatePro10', ...
%               'A06_Huawei-Y5', 'A07_Galaxy-S7', 'A08_Galaxy-S7', 'A09_Galaxy-Note5', ...
%               'A10_Galaxy-J7', 'A11_Xiaomi5', 'A12_Huawei-RY6', 'A13_Huawei-RY6', ...
%               'A14_Xiaomi-5A', 'A15_Xiaom-3', 'A16_OnePlus-3t', 'A17_AsusZenfone-2', ...
%               'I01_iphone8', 'I02_iphonese', 'I03_iphone7', 'I04_iPad-Air', ...
%               'I05_iphone6', 'I06_iphone-5S'};
% 
% % ��ȡ˳��
% extractOrder = {
%     'A01', 'A02'; 'A02', 'A04'; 'A03', 'A17'; 'A04', 'A05'; 'A05', 'A04';
%     'A06', 'A12'; 'A07', 'A10'; 'A08', 'A14'; 'A09', 'A15'; 'A10', 'A07';
%     'A11', 'A16'; 'A12', 'A13'; 'A13', 'A12'; 'A14', 'A08'; 'A15', 'A09';
%     'A16', 'A10'; 'A17', 'A03'; 'I01', 'I03'; 'I02', 'I03'; 'I03', 'I02';
%     'I04', 'A03'; 'I05', 'I06'; 'I06', 'I05'
% };


% �豸�б�
devices = {'D01_Xiaomi-Mi5-0','D02_Xiaomi-Mi5-zw','D03_Xiao-Note4-hf','D04_Xiao-Note4-kc','D05_Xiao-Note4-lq', ...
           'D06_Xiao-Note4-wq','D07_Xiao-Note4-yy','D08_HUAWEI_R9','D09_iphone6s','D10_iphone7plus', ...
           'D11_iphoneSE','D12_P10','D13_RY6_plus_0','D14_RY6_plus_1','D15_LEShi_P3','D16_iPhoneX',...
           'D17_HUAWEI_mate30pro','D18_HUAWEI_mate30pro','D19_iphone12','D20_iphone12','D21_iphone12',...
           'D22_oppo reno5','D23_XiaomiCivi4pro','D24_XiaoMi14','D25_OPPO find X3','D26_HUAWEI_nova7',...
           'D27_HUAWEI_R10L','D28_Xiao-Note3'};

% ��ȡ˳��
extractOrder = {
    'D01', 'D02'; 'D02', 'D15'; 'D03', 'D04'; 'D04', 'D03'; 'D05', 'D06';
    'D06', 'D05'; 'D07', 'D06'; 'D08', 'D14'; 'D09', 'D11'; 'D10', 'D11';
    'D11', 'D09'; 'D12', 'D13'; 'D13', 'D07'; 'D14', 'D08'; 'D15', 'D02';
    'D16', 'D09'; 'D17', 'D12'; 'D18', 'D17'; 'D19', 'D20'; 'D20', 'D21';
    'D21', 'D19'; 'D22', 'D25'; 'D23', 'D24'; 'D24', 'D23'; 'D25', 'D22';
    'D26', 'D15'; 'D27', 'D13'; 'D28', 'D24';
};

% ÿ����ȡ��������������
 sampleSize = [300, 300, 130, 130, 120, 120, 120, 300, 300, 300, 300, 300, 120, 300, 300,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120];
% sampleSize = 20;
% sampleSize = [15,15, 20,20,20,20,20,20, 20];
%sampleSize = [300, 300, 130, 130, 120, 120, 120, 300, 300, 300, 300, 300, 120, 120, 300];
%% CameraID parameters
Par = []; % �ṹ�����

Par.Fcleaned = false; % Assuming fingerprints are already "clean" (LP is removed, and WienerInDFT applied)
Par.scalerange = [0.9, 1.02]; % For brute-force (BF) search
% Par.scalerange = [0.8, 1.0204];
% Par.scalerange = [0.8, 1.5];
Par.scalestep = 0.002; % For brute-force search
% Par.scalestep = 0.001; 
Par.th4pce = 26; % ��ֵ
Par.maxshift = 100; % Maximum acceptable phase shift for the blocks


Par.blkszeN = 240; % Size of the blocks
% Par.blkszeN = 256; % Size of the blocks
% Par.blkszeN = 128;

Par.stride = 80; % ��֮��Ĳ���
% Par.stride = 128; % ��֮��Ĳ���

Par.saveDotPlot = true; % �Ƿ񱣴� dotplot

results = [];

% % % %D01-D28
datasetDir = 'E:\HDR\Xiaomi-New\';
fingerprintDir = 'E:\HDR\Xiaomi-New-out\fingerprintSingle\';
outputDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8';
PCEgtDir = fullfile(outputDir, 'PCE-HDR', 'gt');
PCEccDir = fullfile(outputDir, 'PCE-HDR', 'cc');
PCE1Dir = fullfile(outputDir, 'PCE-HDR', 'pce1');
PCE2Dir = fullfile(outputDir, 'PCE-HDR', 'pce2');
resultDir = fullfile(outputDir, 'result-HDR');
ROCDir = fullfile(outputDir, 'ROC-HDR');
allpathDir = fullfile(outputDir, 'allpath-HDR');

% Ensure the directories exist
if ~exist(PCEgtDir, 'dir')
    mkdir(PCEgtDir);
end
if ~exist(PCEccDir, 'dir')
    mkdir(PCEccDir);
end
if ~exist(PCE1Dir, 'dir')
    mkdir(PCE1Dir);
end
if ~exist(PCE2Dir, 'dir')
    mkdir(PCE2Dir);
end
if ~exist(resultDir, 'dir')
    mkdir(resultDir);
end
if ~exist(ROCDir, 'dir')
    mkdir(ROCDir);
end
if ~exist(allpathDir, 'dir')
    mkdir(allpathDir);
end

% 
% %%%%%A01-A23
% outputDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8';
% PCEgtDir = fullfile(outputDir, 'PCE-HDR', 'gt');
% PCEccDir = fullfile(outputDir, 'PCE-HDR', 'cc');
% PCE1Dir = fullfile(outputDir, 'PCE-HDR', 'pce1');
% PCE2Dir = fullfile(outputDir, 'PCE-HDR', 'pce2');
% resultDir = fullfile(outputDir, 'result-HDR');
% ROCDir = fullfile(outputDir, 'ROC-HDR');
% allpathDir = fullfile(outputDir, 'allpath-HDR');
% 
% % % % % Ensure the directories exist
% if ~exist(PCEgtDir, 'dir')
%     mkdir(PCEgtDir);
% end
% if ~exist(PCEccDir, 'dir')
%     mkdir(PCEccDir);
% end
% if ~exist(PCE1Dir, 'dir')
%     mkdir(PCE1Dir);
% end
% if ~exist(PCE2Dir, 'dir')
%     mkdir(PCE2Dir);
% end
% if ~exist(resultDir, 'dir')
%     mkdir(resultDir);
% end
% if ~exist(ROCDir, 'dir')
%     mkdir(ROCDir);
% end
% if ~exist(allpathDir, 'dir')
%     mkdir(allpathDir);
% end

allGroundTruth = [];
allPCEvalues = [];
allPCE1values = [];
allPCE2values = [];
% 18  27   24  21  20   14  219  139
% for i = 18:length(extractOrder)
for i = 20
    iterationStartTime = tic; % ��ʼ��ʱ

    posDevice = extractOrder{i, 1};
    negDevice = extractOrder{i, 2};

%     posSampleSize = sampleSize(find(contains(devices, posDevice)));
%     negSampleSize = posSampleSize;

    % �ҵ���Ӧ�豸����
    posIndex = find(contains(devices, posDevice));
    negIndex = find(contains(devices, negDevice));


    posSampleSize = sampleSize(posIndex);
    negSampleSize = posSampleSize;

% 
%     posSampleSize = sampleSize;
%     negSampleSize = sampleSize;

%     posDir = fullfile('E:\1\post\paper\PRNU-sourcecode\HDR-Dataset', devices{startsWith(devices, posDevice)}, 'NAT','HDR_HAND');
%     posFiles = dir(fullfile(posDir, '*.jpg'));
%     posPaths = {posFiles(~contains({posFiles.name}, '._')).name};
%     posPaths = fullfile(posDir, posPaths(1:posSampleSize));
% 
%     negDir = fullfile('E:\1\post\paper\PRNU-sourcecode\HDR-Dataset', devices{startsWith(devices, negDevice)}, 'NAT','HDR_HAND');    
%     negFiles = dir(fullfile(negDir, '*.jpg'));     
%     negPaths = {negFiles(~contains({negFiles.name}, '._')).name};
%     negPaths = fullfile(negDir, negPaths(1:negSampleSize));

    posDir = fullfile(datasetDir,devices{posIndex} , 'HDR-NAT');
    posFiles = dir(fullfile(posDir, '*.jpg'));
    posPaths = {posFiles(~contains({posFiles.name}, '._')).name};
    posPaths = fullfile(posDir, posPaths(1:posSampleSize));

    negDir = fullfile(datasetDir, devices{negIndex}, 'HDR-NAT');    
    negFiles = dir(fullfile(negDir, '*.jpg'));     
    negPaths = {negFiles(~contains({negFiles.name}, '._')).name};
    negPaths = fullfile(negDir, negPaths(1:negSampleSize));

    % Combine positive and negative samples
    allPaths = [posPaths, negPaths];

    % ���� allPaths �� .mat �ļ�
    save(fullfile(outputDir, 'allpath-HDR',[posDevice '-allPaths.mat']), 'allPaths');

    groundTruth = [ones(1, length(posPaths)), zeros(1, length(negPaths))];
    
    % Save the ground truth
    save(fullfile(PCEgtDir, [posDevice '-' negDevice '.mat']), 'groundTruth');
    
%     Load fingerprint for the current positive device
%     fingerprintPath = fullfile('E:\1\post\paper\PRNU-sourcecode\HDRcode\HDR_fingerpirnt', devices{startsWith(devices, posDevice)}, 'fingerprint.mat');
    fingerprintPath = fullfile(fingerprintDir, devices{posIndex}, 'fingerprint.mat');
    if ~isfile(fingerprintPath)
        error('Fingerprint file not found: %s', fingerprintPath);
    end
    fingerprintData = load(fingerprintPath);
    Fingerprint = fingerprintData.RP;
    Par.path2F = fingerprintPath;
    
    % Calculate PCE values
    PCE_values = zeros(1, length(allPaths));
    PCE1_values = zeros(1, length(allPaths));
    PCE2_values = zeros(1, length(allPaths));
    for j = 1:length(allPaths)
%     for j = 98
%     for j = [205,211,218]
        I = imread(allPaths{j});
        [~, Par.imgName, ext] = fileparts(allPaths{j});
        cameraName = strsplit(Par.path2F, filesep);

        if length(cameraName) > 1, cameraName = cameraName{end-1}; else, cameraName = 'Camera'; end

        if strcmpi(ext, '.tif') && size(I, 3) == 4, I(:, :, 4) = []; end
        if size(I, 1) < size(I, 2), I = rot90(I); end

        if size(I, 1) ~= size(Fingerprint, 1) || size(I, 2) ~= size(Fingerprint, 2)
            I = imcropmiddle(I, [size(Fingerprint, 1), size(Fingerprint, 2)]);
        end

        if all(I(:)==1) || all(I(:)==0)
            disp('Invalid Image: dark or saturated');
        return;

        else  
            % set seed for random numbers:
            %���������������������Ϊ123��������������㷨Ϊ 'twister'
            rng(123,'twister');      
        


       [PCEout, Wt,TraPar,Par_out] = CameraID(I, cameraName, Par);
        Par_out.Ffft = []; Par_out.Fblkfft = []; Par_out.NFout.F_out = []; Par_out.F = []; Par_out.W=[];
%         disp(PCEout.BC)
%         disp(['After PW: ',mat2str(PCEout.AC)])
        PCE1_values(j) = max(Par_out.PCEbc, PCEout.AC);

%         PCE1_values(j) = PCEout.BC;

        modifyPaths();
% 
%         I_rot = imrotate(I, 180);
% 
%         
        [PCEout_rot, Wt_rot,TraPar_rot,Par_out_rot] = CameraID(I_rot,cameraName, Par);        
        Par_out_rot.Ffft = []; Par_out_rot.Fblkfft = []; Par_out_rot.NFout.F_out = []; Par_out_rot.F = []; Par_out_rot.W=[];

        PCE2_values(j) = max(Par_out_rot.PCEbc, PCEout_rot.AC);

%         PCE2_values(j) = PCEout_rot.BC;
        PCE_values(j) = max(PCE1_values(j), PCE2_values(j));

        modifyPathsBack();
      
        end
    end
    
    % Save the PCE values
    save(fullfile(PCEccDir, [posDevice '-' negDevice '.mat']), 'PCE_values');
    save(fullfile(PCE1Dir, [posDevice '-' negDevice '.mat']), 'PCE1_values');
    save(fullfile(PCE2Dir, [posDevice '-' negDevice '.mat']), 'PCE2_values');
    
    % Append to overall ground truth and PCE values
    allGroundTruth = [allGroundTruth, groundTruth];
    allPCEvalues = [allPCEvalues, PCE_values];
    allPCE1values = [allPCE1values, PCE1_values];
    allPCE2values = [allPCE2values, PCE2_values];
    
    % Calculate ROC, AUC, TPR, and FPR for current pair
    [X, Y, T, AUC] = perfcurve(groundTruth, PCE_values, 1);
    threshold = 60;
    tp = sum((PCE_values >= threshold) & (groundTruth == 1));
    fp = sum((PCE_values >= threshold) & (groundTruth == 0));
    fn = sum((PCE_values < threshold) & (groundTruth == 1));
    tn = sum((PCE_values < threshold) & (groundTruth == 0));
    tpr = tp / (tp + fn);
    fpr = fp / (fp + tn);

    % Store the results
    result = struct('posDevice', posDevice, 'negDevice', negDevice, 'AUC', AUC, 'TPR', tpr, 'FPR', fpr);
    results = [results; result];
    
    % Save the results
    save(fullfile(resultDir, [posDevice '-' negDevice '.mat']), 'result');
    
    % Plot ROC curve
    figure('Visible', 'off');
    lw = 2;
    plot(X, Y, 'Color', [1, 0.549, 0], 'LineWidth', lw);  % ʹ�� RGB ֵָ�����ɫ
    hold on;
    plot([0, 1], [0, 1], 'Color', 'b', 'LineWidth', lw, 'LineStyle', '--');  % ʹ����ɫ
    hold off;
    xlim([0.0, 1.0]);
    ylim([0.0, 1.05]);
    xlabel('False Positive Rate');
    ylabel('True Positive Rate');
    title(['ROC Curve for ', posDevice, ' vs ', negDevice]);
    legend('ROC curve', 'Location', 'southeast');
    set(gca, 'TickDir', 'in');  
    saveas(gcf, fullfile(ROCDir, [posDevice '-' negDevice '_ROC.jpg']));
    close(gcf);

    % ��ʾ��ǰѭ���ļ���ʱ��
    iterationTime = toc(iterationStartTime);
    fprintf('ѭ�� %d �ļ���ʱ��: %f ��\n', i, iterationTime);
end

