function modify()
    % 定义要修改的文件目录
    dirPath = 'E:\Code\test\Matlab_Run\src';
    
 
%         oldPath1 = 'E:\\HDR\\XiaomiHDRout\\PCE-HDR';
%         newPath1 = 'G:\\2\\XiaomiHDRout\\PCE';
% 
%         oldPath2 = 'E:\\HDR\\XiaomiHDRout\\middle-HDR';
%         newPath2 = 'G:\\2\\XiaomiHDRout\\middle';
% 
%         oldPath3 = 'E:\\HDR\\XiaomiHDRout\\allpath-HDR';
%         newPath3 = 'G:\\2\\XiaomiHDRout\\allpath';


        oldPath1 = 'G:\\2\\XiaomiHDRout\\PCE';
        newPath1 = 'E:\\HDR\\XiaomiHDRout\\PCE-HDR';

        oldPath2 = 'G:\\2\\XiaomiHDRout\\middle';
        newPath2 = 'E:\\HDR\\XiaomiHDRout\\middle-HDR';

        oldPath3 = 'G:\\2\\XiaomiHDRout\\allpath';
        newPath3 = 'E:\\HDR\\XiaomiHDRout\\allpath-HDR';



    % 获取目录下所有的 .m 文件
    files = dir(fullfile(dirPath, '*.m'));
    
    % 处理 CameraID.m 文件
    cameraIDFile = fullfile(dirPath, 'block5.m');
    if isfile(cameraIDFile)
        modifyFilePaths(cameraIDFile, oldPath1, newPath1);
        modifyFilePaths(cameraIDFile, oldPath2, newPath2);  
        modifyFilePaths(cameraIDFile, oldPath3, newPath3);
    end
    

    function modifyFilePaths(filePath, oldPath, newPath)
        % 读取文件内容
        fileText = fileread(filePath);
        
        % 替换旧路径为新路径
        newText = strrep(fileText, oldPath, newPath);
        
        % 将修改后的内容写回文件
        fid = fopen(filePath, 'w');
        fwrite(fid, newText);
        fclose(fid);
        
        % 输出修改信息
%         fprintf('Modified file: %s\n', filePath);
    end
end
