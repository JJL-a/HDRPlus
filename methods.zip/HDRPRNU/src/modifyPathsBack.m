function modifyPathsBack()
    % ����Ҫ�޸ĵ��ļ�Ŀ¼
    dirPath = 'E:\Code\test\Matlab_Run\src\relF';
    
    % ����Ҫ���Һ��滻��·���������ж��飩
    % ÿ����һ����·�� �� ��·����ӳ��
    replacements = {
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\dot-HDR-180\', ...
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\dot-HDR\';
        
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\middle-HDR-180', ...
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\middle-HDR';

         % ���2��fullfile ��ͷ��ע������������ '' �Ͷ��� ,��        
        'fullfile(''E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\middle-HDR-180', ...
        'fullfile(''E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\middle-HDR';
        
        
%         ���Լ������Ӹ���·���ԣ�ÿ����һ�飨oldPath, newPath��
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\His-HDR-180', ...
        'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\8\His-HDR';
    };
    
    % ��ȡĿ¼�����е� .m �ļ�
    files = dir(fullfile(dirPath, '*.m'));
    
    if isempty(files)
        fprintf('No .m files found in directory: %s\n', dirPath);
        return;
    end
    
    % ͳ���޸��˶����ļ�
    modifiedCount = 0;
    
    % �������� .m �ļ�
    for i = 1:length(files)
        filePath = fullfile(dirPath, files(i).name);
        
        % ��ȡ�ļ�����
        try
            fileText = fileread(filePath);
        catch ME
            warning('Failed to read file: %s\n    Reason: %s\n', filePath, ME.message);
            continue;
        end
        
        originalText = fileText;
        
        % ��ÿһ���滻������д���
        for k = 1:2:size(replacements, 1)
            oldPath = replacements{k, 1};
            newPath = replacements{k, 2};
            
            % ִ���ַ����滻
            fileText = strrep(fileText, oldPath, newPath);
        end
        
        % ��������Ƿ����˱仯
        if ~strcmp(originalText, fileText)
            % д���޸ĺ������
            try
                fid = fopen(filePath, 'w');
                fwrite(fid, fileText, 'char');
                fclose(fid);
%                 fprintf('Modified: %s\n', filePath);
                modifiedCount = modifiedCount + 1;
            catch ME
                warning('Failed to write file: %s\n    Reason: %s\n', filePath, ME.message);
            end
        end
    end
    
    % ����ܽ�
%     fprintf('Path replacement completed.\n');
%     fprintf('Total .m files processed: %d\n', length(files));
    fprintf('Files re_modified: %d\n', modifiedCount);
end


% 
% function modifyPathsBack()
%     % ����Ҫ�޸ĵ��ļ�Ŀ¼
%     dirPath = 'E:\Code\test\Matlab_Run\src\relF';
%     
%     % ����Ҫ���Һ��滻��·��
%     %�к�159 CameraID
% % 
% % %     oldPath1 = 'E:\HDR\XiaomiHDRout\dot-HDR-180\';
% %     oldPath1 = 'E:\HDR\XiaomiHDRout\dot-180\';
% % %     newPath1 = 'E:\HDR\XiaomiHDRout\dot-HDR\';
% %     newPath1 = 'E:\HDR\XiaomiHDRout\dot\';
% %     
% % %     oldPath2 = 'E:\HDR\XiaomiHDRout\middle-HDR-180';
% %     oldPath2 = 'E:\HDR\XiaomiHDRout\middle-180';
% % %     newPath2 = 'E:\HDR\XiaomiHDRout\middle-HDR';
% %     newPath2 = 'E:\HDR\XiaomiHDRout\middle';
%     
% % 
%         oldPath1 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout_128\dot-HDR-180\';
%         newPath1 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout_128\dot-HDR\';
% 
%         oldPath2 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout_128\middle-HDR-180';
%         newPath2 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout_128\middle-HDR';
% % 
% %         oldPath3 = 'E:\HDR\XiaomiHDRout\His-HDR-180';
% %         newPath3 = 'E:\HDR\XiaomiHDRout\His-HDR';
% 
%     % ��ȡĿ¼�����е� .m �ļ�
%     files = dir(fullfile(dirPath, '*.m'));
%     
%     % ���� CameraID.m �ļ�
%     cameraIDFile = fullfile(dirPath, 'CameraID.m');
%     if isfile(cameraIDFile)
%         modifyFilePaths(cameraIDFile, oldPath1, newPath1);
%         modifyFilePaths(cameraIDFile, oldPath2, newPath2);                                                                                                              
%     end
% 
%     cameraIDFile1 = fullfile(dirPath, 'CameraID_sc1.m');
%     if isfile(cameraIDFile1)
%         modifyFilePaths(cameraIDFile1, oldPath1, newPath1);
%         modifyFilePaths(cameraIDFile1, oldPath2, newPath2);                                                                                                              
%     end
% 
%     % ���� getScalingFromBlocks.m �ļ�
%     scalingFile = fullfile(dirPath, 'getScalingFromBlocks.m');
%     if isfile(scalingFile)
%         modifyFilePaths(scalingFile, oldPath2, newPath2);
%     end
% 
%     % ���� getScalingFromBlocks.m �ļ�
% %     scalingFile = fullfile(dirPath, 'getScalingFromBlocks.m');  %getScaling_scale1
%     scalingFile1 = fullfile(dirPath, 'getScaling_scale1.m');
%     if isfile(scalingFile1)
%         modifyFilePaths(scalingFile1, oldPath2, newPath2);
%     end
%     
%     % ���� DetectByBlocks.m �ļ�
%     detectFile = fullfile(dirPath, 'DetectByBlocks.m');
%     if isfile(detectFile)
%         modifyFilePaths(detectFile, oldPath1, newPath1);
%         modifyFilePaths(detectFile, oldPath2, newPath2); 
%     end
%     
%     % ���� patchworkOnHDR.m �ļ�
%     patchworkFile = fullfile(dirPath, 'patchworkOnHDR.m');
%     if isfile(patchworkFile)
%         modifyFilePaths(patchworkFile, oldPath1, newPath1);
%         modifyFilePaths(patchworkFile, oldPath2, newPath2);
% %         modifyFilePaths(patchworkFile, oldPath3, newPath3);
%     end
%     
% %     fprintf('All specified files have been modified.\n');
%     
%     function modifyFilePaths(filePath, oldPath, newPath)
%         % ��ȡ�ļ�����
%         fileText = fileread(filePath);
%         
%         % �滻��·��Ϊ��·��
%         newText = strrep(fileText, oldPath, newPath);
%         
%         % ���޸ĺ������д���ļ�
%         fid = fopen(filePath, 'w');
%         fwrite(fid, newText);
%         fclose(fid);
%         
%         % ����޸���Ϣ
% %         fprintf('Modified file: %s\n', filePath);
%     end
% end
