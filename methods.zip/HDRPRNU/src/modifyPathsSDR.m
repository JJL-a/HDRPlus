function modifyPaths()
    % 定义要修改的文件目录
    dirPath = 'E:\Code\test\Matlab_Run\src\relF';
    
    % 定义要查找和替换的路径
    %行号159 CameraID

    oldPath1 = 'E:\HDR\DHIF\HDR-PRNUout\dot\';
%     newPath1 = 'E:\IMCE\HDR-PRNUout\dot-180\';
    
    newPath1 = 'E:\HDR\DHIF\HDR-PRNUout\dot-180\';

    oldPath2 = 'E:\HDR\DHIF\HDR-PRNUout\middle';
    newPath2 = 'E:\HDR\DHIF\HDR-PRNUout\middle-180';
    
    % 获取目录下所有的 .m 文件
    files = dir(fullfile(dirPath, '*.m'));
    
    % 处理 CameraID.m 文件
    cameraIDFile = fullfile(dirPath, 'CameraID.m');
    if isfile(cameraIDFile)
        modifyFilePaths(cameraIDFile, oldPath1, newPath1);
        modifyFilePaths(cameraIDFile, oldPath2, newPath2);                                                                                                              
    end
    
    % 处理 getScalingFromBlocks.m 文件
    scalingFile = fullfile(dirPath, 'getScalingFromBlocks.m');
    if isfile(scalingFile)
        modifyFilePaths(scalingFile, oldPath2, newPath2);
    end
    
    % 处理 DetectByBlocks.m 文件
    detectFile = fullfile(dirPath, 'DetectByBlocks.m');
    if isfile(detectFile)
        modifyFilePaths(detectFile, oldPath1, newPath1);
        modifyFilePaths(detectFile, oldPath2, newPath2); 
    end
    
    % 处理 patchworkOnHDR.m 文件
    patchworkFile = fullfile(dirPath, 'patchworkOnHDR.m');
    if isfile(patchworkFile)
        modifyFilePaths(patchworkFile, oldPath1, newPath1);
        modifyFilePaths(patchworkFile, oldPath2, newPath2);
    end
    
%     fprintf('All specified files have been modified.\n');
    
    function modifyFilePaths(filePath, oldPath, newPath)
        % 读取文件内容
        fileText = fileread(filePath);
        
        % 替换旧路径为新路径
        newText = strrep(fileText, oldPath, newPath);
        
        % 将修改后的内容写回文件
        fid = fopen(filePath, 'w');
        fwrite(fid, newText);
        fclose(fid);
        
        % 输出修改信息
%         fprintf('Modified file: %s\n', filePath);
    end
end
