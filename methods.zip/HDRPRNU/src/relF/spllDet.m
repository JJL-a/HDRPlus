function [N_RNG,F_RNG,ccMTX, dtMTX, PCEsMTX, Fblkfft, NFout] = spllDet(N,F,blkszeN,blkszeF,stride, Fblkfft, maxshift, NFout)
%%% �Copyright DDELab, SUNY Binghamton                      %%%
%FUNCTION Splits HDR image then computes maximum cross-correlation in each
%split (within a distance from the corners in cross-correlation matrix).
%Splits can be overlapped. Splitting settings are set inside the code.
%
% Input:
%   - N
%       Noise matrix
%   - F
%       camera fingerprint
%   - blkszeN
%       size of the blocks from N
%   - blkszeF
%       size of the blocks from F
%   - stride
%       stride for blocks from both N and F
%   - Fblkfft (optional)
%       4D array of FFt of the blocks, if exists
%   - maxshift
%       maximum shift for search for PCE function (always positive,
%       but is used as "pce_= PCE(C,-Par.maxshift)"
%   - NFout
%       NFout.{N_RNG, F_RNG} ranges for blocks of F and N  
%
% Output:
%   - N_RNG
%       4D matrix representing range of the blocks from N in form 
%       [r1 c1; r2 c2] for the first two dimensions, where r2>r1 and
%       c2>c1. The two last dimensions determine index of the block.
%   - F_RNG
%       Similar to N_RNG but for F (instead of N) 
%   - ccMTX
%       matrix of cross-correlation peaks
%   - dtMTX
%       matrix of detected locations
%   - PCEsMTX
%       matrix of PCE values in the found peaks
%   - Fblkfft
%       4D array of FFt of the blocks from F
%   - NFout
%       NFout.{N_RNG, F_RNG} ranges for blocks of F and N  

Fe = false; % flag for "Fblkfft exists"
if exist('Fblkfft','var')
    if ~isempty(Fblkfft)
        Fe = true;
    end
end 
NFoutEXIST = false;
if exist('NFout','var')
    if ~isempty(NFout)
        NFoutEXIST = true;
    end
end
if NFoutEXIST
    [N_RNG, F_RNG, F_out] = deal(NFout.N_RNG, NFout.F_RNG, NFout.F_out);
else
    [N_RNG, F_RNG, F_out] = NFsplitter_mod(N, F, stride, blkszeN, blkszeF);
end

if ~Fe
    if numel(blkszeF)==1, z = [blkszeF,blkszeF];else, z = blkszeF(:)';end
    Fblkfft = zeros([z,size(N_RNG,3),size(N_RNG,4)],'single');
end

PCEsMTX = zeros(size(N_RNG,3),size(N_RNG,4),'single');
ccMTX   = zeros(size(N_RNG,3),size(N_RNG,4),'single');
dtMTX   = zeros(2,size(N_RNG,3),size(N_RNG,4));
for i = 1 : size(N_RNG,3)
    for j = 1 : size(N_RNG,4)
        RN = N_RNG(:,1,i,j);
        CN = N_RNG(:,2,i,j);
        RF = F_RNG(:,1,i,j);
        CF = F_RNG(:,2,i,j);
        %% PRNU checking
        [Nx,Fx] = samesize(N(RN(1):RN(2),CN(1):CN(2)),...
                           F_out(RF(1):RF(2),CF(1):CF(2)),'pad');  % N大小为240，上下左右填充
        if Fe
            [C, ~, ~] = crosscor2_modified(Nx, Fx, [], Fblkfft(:,:,i,j));
        else
            [C, ~, Fblkfft(:,:,i,j)] = crosscor2_modified(Nx, Fx, [], []);
        end
        Peak = PCE(C,-maxshift);
        [ccMTX(i,j), dtMTX(:,i,j), PCEsMTX(i,j)] =...
            deal(Peak.peakheight, Peak.PeakLocation, Peak.PCE);
    end
end

if ~NFoutEXIST
    [NFout.N_RNG, NFout.F_RNG, NFout.F_out] = deal(N_RNG, F_RNG, F_out);
end

end
