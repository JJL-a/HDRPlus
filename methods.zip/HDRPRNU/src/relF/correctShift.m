function outMTX = correctShift(dtMTX)

rdt = reshape(dtMTX,[2,size(dtMTX,2)*size(dtMTX,3)]);  %每个块的移位坐标逐个展开
[~, ptsC, centres] = dbscan(rdt, 1.5, 5);%ptsC为每个块所属聚类编号   centres为每个聚类的中心坐标（移位）
centres = round(centres);%矩阵，其中每列表示一个簇的中心坐标
N = size(centres,2);
for i = 1:N   %每个聚类里的块使用同样的中心坐标
    rdt(1,ptsC==i)=centres(1,i);%第 i 个聚类的所有块的 x 坐标
    rdt(2,ptsC==i)=centres(2,i);%第 i 个聚类的所有块的 y 坐标
end
outMTX = reshape(rdt,size(dtMTX));%变回dtMTX的形式
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                  %
%       Below is NOT my own implementation!        %
%                                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% DBSCAN DBSCAN clustering algorithm
% 
% Usage:  [C, ptsC, centres] = dbscan(P, E, minPts)
% 
% Arguments:
%         P - dim x Npts array of points.
%         E - Distance threshold.
%    minPts - Minimum number of points required to form a cluster.
% 
% Returns:
%         C - Cell array of length Nc listing indices of points associated with
%             each cluster.
%      ptsC - Array of length Npts listing the cluster number associated with
%             each point.  If a point is denoted as noise (not enough nearby
%             elements to form a cluster) its cluster number is 0.
%   centres - dim x Nc array of the average centre of each cluster.
% 
% Reference:
% Martin Ester, Hans-Peter Kriegel, J�rg Sander, Xiaowei Xu (1996). "A
% density-based algorithm for discovering clusters in large spatial databases
% with noise".  Proceedings of the Second International Conference on Knowledge
% Discovery and Data Mining (KDD-96). AAAI Press. pp. 226-231.  
% Also see: http://en.wikipedia.org/wiki/DBSCAN
% 
% Copyright (c) 2013 Peter Kovesi
% Centre for Exploration Targeting
% The University of Western Australia
% peter.kovesi at uwa edu au
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in 
% all copies or substantial portions of the Software.
% 
% The Software is provided "as is", without warranty of any kind.
% 
% PK January 2013

function [C, ptsC, centres] = dbscan(P, E, minPts) %dbscan(rdt, 1.5, 5)
    
    [dim, Npts] = size(P);
    
    ptsC  = zeros(Npts,1);%记录每个点属于哪个聚类
    C     = {};  %第几簇包含哪几个块
    Nc    = 0;               % Cluster counter. 簇数
    Pvisit = zeros(Npts,1);  % Array to keep track of points that have been visited.
    
    for n = 1:Npts
       if ~Pvisit(n)                            % If this point not visited yet
           Pvisit(n) = 1;                       % mark as visited
           neighbourPts = regionQuery(P, n, E); % and find its neighbours 
            %找到在 P 中与点 P(:,n) 距离小于 E 的所有点，并返回这些点的索引
           if length(neighbourPts) < minPts-1  % Not enough points to form a cluster  每个簇至少有5个成员
               ptsC(n) = 0;                    % Mark point n as noise.
           
           else                % Form a cluster...
               Nc = Nc + 1;    % Increment number of clusters and process
                               % neighbourhood.
           
               C{Nc} = [n];    % Initialise cluster Nc with point n  后续加入更多可能的块（逐个找邻居）
               ptsC(n) = Nc;   % and mark point n as being a member of cluster Nc.
               
               ind = 1;        % Initialise index into neighbourPts array.
               
               % For each point P' in neighbourPts ...
               while ind <= length(neighbourPts)
                   
                   nb = neighbourPts(ind);  %对n的邻居遍历寻找邻居
                   
                   if ~Pvisit(nb)        % If this neighbour has not been visited
                       Pvisit(nb) = 1;   % mark it as visited.
                       
                       % Find the neighbours of this neighbour and if it has
                       % enough neighbours add them to the neighbourPts list
                       neighbourPtsP = regionQuery(P, nb, E);
                       if length(neighbourPtsP) >= minPts
                           neighbourPts = [neighbourPts  neighbourPtsP];
                       end
                   end            
                   
                   % If this neighbour nb not yet a member of any cluster add it
                   % to this cluster.
                   if ~ptsC(nb)  % 如果块nb还没有被分类到簇
                       C{Nc} = [C{Nc} nb];%将块nb添加到第Nc个簇中
                       ptsC(nb) = Nc;%块nb标记为属于哪个簇
                   end
                   
                   ind = ind + 1;  % Increment neighbour point index and process
                                   % next neighbour
               end
           end
       end
    end
    
    % Find centres of each cluster
    centres = zeros(dim,length(C));
    for n = 1:length(C) %遍历C中的每个簇
        for k = 1:length(C{n})  %遍历第n个簇中每个块
            centres(:,n) = centres(:,n) + P(:,C{n}(k));%将第n个簇中所有块的坐标累加起来
        end
        centres(:,n) = centres(:,n)/length(C{n});%除以该簇中块的数量，以计算平均值，从而得到簇中心的坐标
    end

end % of dbscan    
    
%------------------------------------------------------------------------
% Find indices of all points within distance E of point with index n
% This function could make use of a precomputed distance table to avoid
% repeated distance calculations, however this would require N^2 storage.
% Not a big problem either way if the number of points being clustered is
% small.   For large datasets this function will need to be optimised.

% Arguments:
%              P - the dim x Npts array of data points
%              n - Index of point of interest
%              E - Distance threshold

function neighbours = regionQuery(P, n, E)
    
    E2 = E^2;   
    [dim, Npts] = size(P);
    neighbours = []; %所有距离目标点 n 在 E 范围内的点的索引
    
    for i = 1:Npts
        if i ~= n
            % Test if distance^2 < E^2 
            v = P(:,i)-P(:,n); %向量差
            dist2 = v'*v;%内积运算  计算这两个点之间的欧几里得距离的平方
            if dist2 < E2  %如果距离的平方小于 E2，则认为点 i 在点 n 的邻域内，将该点的索引 i 添加到 neighbours 数组中
               neighbours = [neighbours i];     
            end
        end
    end
    
end % of regionQuery

