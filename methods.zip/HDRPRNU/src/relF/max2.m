function [maxvalue,locationxy] = max2(X)
% function [maxvalue,locationxy] = max2(X) outputs the maximum and two coordinates of the maximum in X

[maxvalue,maxloc] = max(X(:));
[ymax,xmax] = ind2sub(size(X),maxloc);
locationxy = [ymax,xmax];