function stblN = stblW (W, N_RNG, dtMTX, PCEsMTX, mask, szeN)
%%% �Copyright DDELab, SUNY Binghamton                      %%%
%FUNCTION shifts blocks of the noise matrix for which PCEsMTX is
%computed; and the shifting for each block is from dtMTX. If the shifting
%falls beyound assumed image size, it will not enforce them. Experiments
%show that iterating this action can lead to a noise plane with high PCE.
%Inputes are to be entered from "splitter_detector2.m" and
%"splitter_detector2.m"
%
%Input:
%   - W
%       2D array of extracted image noise.
%   - N_RNG
%       4-D matrix representing range of the blocks in form [r1 c1; r2 c2] for
%       the first two dimensions, where r2>r1 and c2>c1. The two last
%       dimensions determine index of the block.
%   - dtMTX
%       3-D matrix representing located peak for each plock in N5D, in
%       format [r;c]
%   - PCEsMTX
%       2-D matrix representing PCEs of the blocks in N5D
%   - mask
%       showing which blocks are allowed to be stabilized
%   - szeN (optional)
%       size of the noise matrix
%
%Output:
%   - stblN
%       2-D array of noise, obtained from N5D. May need padding.
%

% # of blocks in row and column
[r, c] = deal(size(N_RNG,3), size(N_RNG,4));

% Maximum size of the the image that has undergone blocking. Therefore,
% can be smaller than size of the original image
if isempty(szeN)
    szeN = N_RNG(2,:,end,end);
end
ranges_old = N_RNG;
% Adding shifts to the ranges  根据位移向量将W中的标记块进行反向移位
for i = 1:r
    for j = 1:c
        if mask(i,j)
            N_RNG(:,1,i,j) = N_RNG(:,1,i,j) + dtMTX(1,i,j);
            N_RNG(:,2,i,j) = N_RNG(:,2,i,j) + dtMTX(2,i,j);
        end
    end
end

%%
% Merging the two first dimension of N5D
N_RNG = reshape(N_RNG, [2,2, r*c]);% check if blocks are okay after this!  重塑为一个三维矩阵
ranges_old = reshape(ranges_old, [2,2, r*c]);
% index for sorting from lower PCE
PCEsMTX = reshape(PCEsMTX, [r*c, 1]);
[~ ,idx] = sort(PCEsMTX,'ascend');

% sorting ranges according to idx:
N_RNG = N_RNG(:,:,idx);
ranges_old = ranges_old(:,:,idx);

stblN = W;%zeros(szeN);

for i = 1 : r*c   %对每个块的坐标进行操作
    yrng = N_RNG(1,1,i):N_RNG(2,1,i);%从移位后的N_RNG 提取第 i 个块的 Y 轴和 X 轴范围
    xrng = N_RNG(1,2,i):N_RNG(2,2,i);
    yrng_old = ranges_old(1,1,i):ranges_old(2,1,i);%从原来的ranges_old提取第 i 个块的 Y 轴和 X 轴范围
    xrng_old = ranges_old(1,2,i):ranges_old(2,2,i);
    % Valid range in X
    xrngVALID = xrng>0 & xrng<szeN(2);
    % Valid range in Y
    yrngVALID = yrng>0 & yrng<szeN(1);
    %将 W 矩阵中对应旧范围内的值复制到 stblN 矩阵中对应新范围内的位置，确保只在有效边界内进行操作
    % Picking only in valid boundary values
    stblN(yrng(yrngVALID),xrng(xrngVALID)) = ...
        W(yrng_old(yrngVALID),xrng_old(xrngVALID));
    
end

%%
end
