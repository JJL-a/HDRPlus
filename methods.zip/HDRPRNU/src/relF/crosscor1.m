function CC = crosscor1(matrix1,matrix2,notzeromean,norm1,norm2)    %notzeromean传进来的是0
%%% �Copyright DDELab, SUNY Binghamton                      %%% C = crosscor1(ImNoise,Par.Ffft,0,[],Par.Fnorm);
% function CC = crosscor1(matrix1,matrix2) computes 2D crosscorrelation of two matrices.
% FFT for the second input can be already replacing the matrix2
% notzeromean    =0 if both matrices are zero mean already (default is 1)
% norm1, norm2   optional parameters needed if either matrix is already FFT transformed
% The matrix2 must be flipped 180 degrees if it is already FFT transformed

if nargin<5, norm2=[]; if nargin<4, norm1=[]; if nargin<3, notzeromean=1; end, end, end
matrix1 = double(matrix1);
matrix2 = double(matrix2);

if notzeromean
    matrix1 = matrix1 - mean(matrix1(:));
    matrix2 = matrix2 - mean(matrix2(:));
end

if isempty(norm1)
    norm1 = sqrt(sum(matrix1(:).^2));
    F1 = fft2(matrix1);
else
    F1 = matrix1;
end

if isempty(norm2)
    norm2 = sqrt(sum(matrix2(:).^2));
    matrix2flipped = fliplr(flipud(matrix2));
    F2 = fft2(matrix2flipped);
else
    F2 = matrix2;
end

F1F2 = F1 .* F2;
norms = norm1*norm2;

if norms==0,
    CC = 0;
else
    CC = real(ifft2(F1F2))/norms;

%     CC = real(ifft2(F1F2)); %做测试用  /norms有没有都不影响最终PCE值，虽然影响了C
end
end
