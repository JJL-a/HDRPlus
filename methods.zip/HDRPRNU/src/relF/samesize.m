function [Iout,Fout, pad_] = samesize(I,F,mode)
%%% �Copyright DDELab, SUNY Binghamton                      %%%
%FUNCTION makes Image (I) and Fingerprint (F) to have same size
%  One of the arrays should be larger in both directions, or equal.
%  It is not still defined for one of them being larger in one direction
% and being small in other direction.
%
% Input:
%   -I
%       Image file
%   -F
%       Fingerprint
%   -mode
%       either 'crop' or 'pad' for both sides
%
[mi,ni,~]=size(I);
[mf,nf,~]=size(F);
[Iout,Fout] = deal(I,F);
pad_.I = [0,0,0,0];% U, D, L, R
pad_.F = [0,0,0,0];% U, D, L, R

if nargin<3, mode='pad'; end
%~
if mi==mf && ni==nf
    return
end
%~
validModes = {'pad','crop','f_holy'};
mustBeMember(mode,validModes); % not supported in older Matlabs

%%
dm = mf-mi;
dn = nf-ni;
switch lower(mode)
    
    case 'pad'
        if (dm>0 && dn>0) || (dm==0 && dn>0) || (dm>0 && dn==0)
            Iout = zeros(mf,nf,size(I,3),class(I));
            cntr = floor(size(Iout)/2);
            
            pad_.I=[cntr(1)-floor(mi/2), size(Iout,1)-(cntr(1)+ceil(mi/2)),...
                    cntr(2)-floor(ni/2), size(Iout,2)-(cntr(2)+ceil(ni/2))];
                
            Iout(...
                cntr(1)-floor(mi/2)+1:cntr(1)+ceil(mi/2),...
                cntr(2)-floor(ni/2)+1:cntr(2)+ceil(ni/2), :)...
                = I;
        elseif (dm<0 && dn<0) || (dm==0 && dn<0) || (dm<0 && dn==0)
            Fout = zeros(mi,ni,size(F,3),class(F));
            cntr = floor(size(Fout)/2);
            
            pad_.F=[cntr(1)-floor(mf/2), size(Fout,1)-(cntr(1)+ceil(mf/2)),...
                    cntr(2)-floor(nf/2), size(Fout,2)-(cntr(2)+ceil(nf/2))];
            
            Fout(...
                cntr(1)-floor(mf/2)+1:cntr(1)+ceil(mf/2),...
                cntr(2)-floor(nf/2)+1:cntr(2)+ceil(nf/2), :)...
                = F;
        else% cropping I and padding to the size of F
            [Iout,pad_1.I] = cropCenter(I,size(F));
            [Iout,~,pad_2] = samesize(Iout,F,'pad');
            
            pad_.I = pad_1.I + pad_2.I;
            pad_.F = pad_2.F;
            
            warning('One dimension of I is larger than F but the other dimension is smaller!');
        end
        
    case 'crop'
        if (dm>0 && dn>0) || (dm==0 && dn>0) || (dm>0 && dn==0)
            cntr = floor(size(F)/2);
            
            pad_.F = - [cntr(1)-floor(mi/2), size(F,1)-(cntr(1)+ceil(mi/2)),...
                        cntr(2)-floor(ni/2), size(F,2)-(cntr(2)+ceil(ni/2))];
            
            Fout = F(...
                cntr(1)-floor(mi/2)+1:cntr(1)+ceil(mi/2),...
                cntr(2)-floor(ni/2)+1:cntr(2)+ceil(ni/2), :);
        elseif (dm<0 && dn<0) || (dm==0 && dn<0) || (dm<0 && dn==0)
            cntr = floor(size(I)/2);
            
            pad_.I = - [cntr(1)-floor(mf/2), size(I,1)-(cntr(1)+ceil(mf/2)),...
                        cntr(2)-floor(nf/2), size(I,2)-(cntr(2)+ceil(nf/2))];
            
            Iout = I(...
                cntr(1)-floor(mf/2)+1:cntr(1)+ceil(mf/2),...
                cntr(2)-floor(nf/2)+1:cntr(2)+ceil(nf/2), :);
        else
            [Iout,pad_.I] = cropCenter(I,size(F));
            [Fout,pad_.F] = cropCenter(F,size(I));
            warning('One dimension of I is larger than F but the other dimension is smaller!');
        end
        
    case 'f_holy'
        Fout = F;
        [Iout,pad_1.I] = cropCenter(I,[mf,nf]);
        [Iout,~, pad_2] = samesize(Iout,F,'pad');
        pad_.I = pad_1.I + pad_2.I;
         
end


end