function [outN, outF, rangesN, rangesF, F] = NFsplitter(N, F, strd, Nsze, Fsze)
%%% �Copyright DDELab, SUNY Binghamton                      %%%
%FUNCTION splits Noise matrix along with Fingerprint matrix into several 
%overlapping images, stick them along an extra dimension
%
%Input:
%   -N
%       Input Noise matrix
%   -F
%       Input Fingerprint matrix
%   -srd
%       Stride for splitting, a scalar or a 2x1 vector
%   -Nsze
%       Size of each blocks from N
%   -Fsze
%       Size of each blocks from F
%
%Output:
%   -outN
%       5-D array of output blocks from N, having 3/1 channel(s) of image as the
%       three first dimensions; as well as index of position of each block
%       in the two last dimensions.
%   -outF
%       5-D array of output blocks from F, having 3/1 channel(s) of image as the
%       three first dimensions; as well as index of position of each block
%       in the two last dimensions.
%   -rangesN
%       4-D matrix representing range of the blocks in form [r1 c1; r2 c2] for
%       the first two dimensions, where r2>r1 and c2>c1. The two last
%       dimensions determine index of the block.--> ranges according to N
%   -rangesF
%       4-D matrix representing range of the blocks in form [r1 c1; r2 c2] for
%       the first two dimensions, where r2>r1 and c2>c1. The two last
%       dimensions determine index of the block.--> ranges according to padded F
%   -F
%       Padded F for which rangesF ara valid
%
%
%~
strd = strd(:);
if numel(strd) == 1
    strd = [strd;strd];
end
Nsze = Nsze(:);
if numel(Nsze) == 1
    Nsze = [Nsze;Nsze];
end
Fsze = Fsze(:);
if numel(Fsze) == 1
    Fsze = [Fsze;Fsze];
end
if any((Fsze-Nsze)<0)
    error('error: size of F blocks should not be smaller than size of N blocks.');
end
%~
if any(size(N)~=size(F))
    error('error: N and F should have same size.');
end
%~

%% Splitting N
imgSze = size(N); if numel(imgSze)==2; imgSze = [imgSze,1]'; end
s = floor(([imgSze(1);imgSze(2)]-Nsze)./strd)'; %number of blocks in either directions
rangesN = zeros([2,2,s]);
outN = zeros([Nsze',imgSze(3),s],class(N));

% centers of the blocks
cntrY = ceil(Nsze(1)/2) : strd(1) : (imgSze(1)-floor(Nsze(1)/2));
cntrX = ceil(Nsze(2)/2) : strd(2) : (imgSze(2)-floor(Nsze(2)/2));
% centeralize the block-centers grid
Ncntr = ceil([imgSze(1);imgSze(2)]/2);
[ccY,ccX] = deal(ceil(mean(cntrY([1,end]))),ceil(mean(cntrX([1,end]))));% centers for the block-centers grid
shiftY = Ncntr(1) - ccY;
shiftX = Ncntr(2) - ccX;
cntrY = cntrY + shiftY;
cntrX = cntrX + shiftX;
% making the grid of centers of the blocks
[X,Y] = meshgrid(cntrX,cntrY);
% size(X) = size(Y). Therefore:
for iy = 1 : size(X,1)
    for ix = 1 : size(X,2)
        rangesN(:,2,iy,ix) = X(iy,ix)+[-ceil(Nsze(2)/2)+1;+floor(Nsze(2)/2)]; % i -> x
        rangesN(:,1,iy,ix) = Y(iy,ix)+[-ceil(Nsze(1)/2)+1;+floor(Nsze(1)/2)]; % j -> y
        outN(:,:,:,iy,ix) = N(...
            rangesN(1,1,iy,ix):rangesN(2,1,iy,ix),...
            rangesN(1,2,iy,ix):rangesN(2,2,iy,ix),:);
    end
end

%% Splitting F
imgSze = size(F); if numel(imgSze)==2; imgSze = [imgSze,1]'; end
% 's' is the same for both F and N
rangesF = zeros([2,2,s]);
outF = zeros([Fsze',imgSze(3),s],class(F));
% padding F if necessary
dsze = Fsze - Nsze;
[preblk, postblk] = deal(floor(dsze/2)+1, ceil(dsze/2)+1);
prepad = [rangesN(1,1,1,1); rangesN(1,2,1,1)] - preblk;
prepad = abs(prepad) .* (prepad<0);
postpad = [size(F,1);size(F,2)] - ([rangesN(2,1,end,end); rangesN(2,2,end,end)] + postblk);
postpad = abs(postpad) .* (postpad<0);
F = padarray(F,prepad,'pre');
F = padarray(F,postpad,'post');
% Finding new rangesF and forming outF
for iy = 1 : size(X,1)
    for ix = 1 : size(X,2)
        rangesF(:,2,iy,ix) = rangesN(:,2,iy,ix)...
            + prepad(2) + [-(preblk(2)-1);postblk(2)-1]; % i -> x
        rangesF(:,1,iy,ix) = rangesN(:,1,iy,ix)...
            + prepad(1) + [-(preblk(1)-1);postblk(1)-1]; % j -> y
        outF(:,:,:,iy,ix) = F(...
            rangesF(1,1,iy,ix):rangesF(2,1,iy,ix),...
            rangesF(1,2,iy,ix):rangesF(2,2,iy,ix),:);
    end
end

end