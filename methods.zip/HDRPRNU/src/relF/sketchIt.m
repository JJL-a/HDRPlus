function fig = sketchIt (ranges, dtMTX, nzsze, PCEmask, map)
%%% �Copyright DDELab, SUNY Binghamton                      %%%

%%%  Author: Morteza Darvish Morshedi Hosseini, March 2019  %%%
%%%   Full Government Purpose Rights                        %%%
%%%   Not for commercial use                                %%%
%FUNCTION draws a plot showing displacement of the peaks for PCEs in small
%blocks.
%
% Input:
%   -ranges
%       4-D matrix representing range of the blocks in form [r1 c1; r2 c2] for
%       the first two dimensions, where r2>r1 and c2>c1. The two last
%       dimensions determine index of the block.
%
%   -dtMTX
%       3-D matrix of shifts found from maxPCE. The two last dimensions
%       determine index of the block.
%
%   -nzsze (optional)
%       size of the Noise matrix
%
%   -PCEmask (optional)
%       Showing which target blocks should be shown
%
% Output:
%   -fig (optional)
%       handler for figure for saving it later. Only if it is called, a new
%       figure will be opened for the function. Otherwise, current opened
%       figure is used for plotting.
%
%

markerSizeLarge = 5; % 大标记的大小
markerSizeSmall = 1; % 小标记的大小

marker.colors = {'black','red','blue','magenta','green','cyan','yellow'};
marker.cntr   = {'o','diamond','square','pentagram','hexagram','>'};
marker.target = {'o', '*', '+', '.', '^', 'v'};
[r, c] = deal(size(ranges,3), size(ranges,4));
if isempty(nzsze)
    nzsze = ranges(2,:,end,end);
end
if isempty(PCEmask)
    PCEmask = ones(r,c,'logical');
end
cneters = floor(.5*(ranges(2,:,:,:)+ranges(1,:,:,:)));
cneters = reshape(cneters,size(cneters,2),size(cneters,3),size(cneters,4)); %[r_cntr; c_cntr]
cneters_shifted = cneters + dtMTX;

out = ones(nzsze);

if nargout == 1
    fig = figure('visible','off');
    %fig = figure('visible','on');
end
imshow(out);
drawnow % 强制更新图形窗口

hold on

Xs_cntr = reshape(cneters(2,:,:),r ,c);%提取所有块的列坐标
Ys_cntr = reshape(cneters(1,:,:),r ,c);%提取所有块的行坐标
Xs_target = reshape(cneters_shifted(2,:,:),r ,c);%提取所有块位移后的列坐标
Ys_target = reshape(cneters_shifted(1,:,:),r ,c);%提取所有块位移后的行坐标

if ~exist('map','var')  %移位前
%     plot(Xs_cntr, Ys_cntr, 'ro', 'MarkerSize', 10,'color',marker.colors{1});  %使用红色 (r) 的圆形 (o) 标记符号来绘制点
%     plot(Xs_target(PCEmask(:)), Ys_target(PCEmask(:)), 'r.',...
%         'MarkerSize', 10,'color',marker.colors{1});  %又通过marker.colors{1} 重新设置了颜色(black)

    plot(Xs_cntr, Ys_cntr, 'ro', 'MarkerSize', markerSizeLarge, 'color', marker.colors{1});
    plot(Xs_target(PCEmask(:)), Ys_target(PCEmask(:)), 'r.',...
        'MarkerSize', markerSizeLarge, 'color', marker.colors{1});


else        %移位后   根据不同的类别标签，分别绘制两个数据集（Xs_cntr, Ys_cntr 和 Xs_target, Ys_target）中的点
    clss = unique ([0;map(:)]);% if we don't have class 0, it should be considered  确保所有的块都绘制出来
    for i = 1:length(clss)

        plot(Xs_cntr(map(:)==clss(i)), Ys_cntr(map(:)==clss(i)), ...
            marker.cntr{i}, 'MarkerSize', markerSizeLarge, 'color', marker.colors{i});
        plot(Xs_target(map(:)==clss(i) & PCEmask(:)),...
             Ys_target(map(:)==clss(i) & PCEmask(:)),...
            marker.target{i}, 'MarkerSize', markerSizeSmall, 'MarkerFaceColor',...
            marker.colors{i}, 'color', marker.colors{i});



%         plot(Xs_cntr(map(:)==clss(i)), Ys_cntr(map(:)==clss(i)), ...
%             marker.cntr{i}, 'MarkerSize', 10,'color',marker.colors{i});
%         plot(Xs_target(map(:)==clss(i) & PCEmask(:)),...
%              Ys_target(map(:)==clss(i) & PCEmask(:)),...
%             marker.target{i},'MarkerSize', 3,'MarkerFaceColor',...
%             marker.colors{i},'color',marker.colors{i});
    end
end

hold off

set(gcf,'Position',[100 100 c*15 r*15]);

end