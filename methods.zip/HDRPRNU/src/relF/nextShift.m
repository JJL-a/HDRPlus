function [map, lblc] = nextShift(dtMTX, PCEmsk)
% %% �Copyright DDELab, SUNY Binghamton                      %%%
% nextShift Outputs a map where blocks with same peak locations appear as
% same labels; labels start at 1 for the most frequent peak location
% and so on to the least frequent location for the last number, allowing the
% user to choose arbitrary number of peak directions to do correction for.
% 
% Input
%   - dtMTX
%       3D matrix of detected locations (from splitter_detector2.m)
% 
%   - PCEmsk
%       (optional) A binary mask showing which blocks are above PCE
%       threshold
% Output
%   - map
%       2D matrix of labels, 1 for the most frequent peak-loc and
%       largest number for the least frequent peak-loc, also 0 is assigned
%       to where is not selected with PCEmsk.
%   - lblc
%       Count of the labels, i.e. how many blocks from each label exist and
%       correponding shift(s) for each label; 0 means excluded, other
%       numbers are classes
%       format : {{classNumber},{count},{correspondingShifts}}

map = zeros([size(dtMTX,2) size(dtMTX,3)],'int32'); 
rdt = reshape(dtMTX,[2,numel(dtMTX)/2]);% reshaped dtMTX --> [[yshift;xshift]..]  三维矩阵变二维矩阵
rdt2 = rdt;
%~
if exist('PCEmsk','var')
    if sum(PCEmsk(:))==0
        warning('No block has PCE above threshold. Check "PCEmsk" matrix.');
        map = zeros(size(PCEmsk));
        lblc = [{0};{numel(map)};{unique(rdt','rows')}];
        return;
    else
        rdt2(:,~PCEmsk(:)) = [];  %去除pce<26的块
    end
end
%~


ctrs_ = unique(rdt2','rows');% centers for shifts --> [[xshifts,yshifts]..]  去除坐标重复的块（几个重复的只留一个）
c1 = unique(ctrs_(:,1),'sorted');%从矩阵 ctrs_ 中提取唯一的 x 坐标，升序排列
c2 = unique(ctrs_(:,2),'sorted');%从矩阵 ctrs_ 中提取唯一的 y 坐标，升序排列
if numel(c1)==1 && numel(c2)~=1, c1 = [c1, c1]; end
if numel(c2)==1 && numel(c1)~=1, c2 = [c2, c2]; end
ctrs = {c1 c2};% centers for 2D histogram  以上的操作是为分箱统计生成二维坐标轴
if numel(ctrs_) > 2  
    [N,c] = hist3(rdt2','Ctrs',ctrs);%矩阵 N(i,j) 的值表示在x轴上位于 ctrs{1}(i) 和y轴上位于 ctrs{2}(j) 的分箱（一个范围而不是一个点）中有多少个pce>26的块
else  % c{1} 是 x 轴的分箱中心点向量，c{2} 是 y 轴的分箱中心点向量
    map(PCEmsk)=1;
    lblc = cell(3,2);
    lblc(:,1) = [{0};{sum(~PCEmsk(:))};{unique(rdt(:,~PCEmsk(:))','rows')}];
    lblc(:,2) = [{1};{sum(PCEmsk(:))};{unique(rdt2','rows')}];
    return;
end
Nvals = sort(unique(N(:)),'descend');%找出矩阵 N 中所有唯一值，并将这些唯一值按降序排列
siz = size(N);
lbl = 1;
for l = 1 : length(Nvals)  
    [i, j] = ind2sub(siz,find(N==Nvals(l)));%返回矩阵 N 中等于 Nvals(l) 的元素的线性索引i，j  得到所有块个数相同的分箱
    for l2 = 1:length(i)% or length(j)   遍历块个数相同的每个分箱
        % --> This "for" is for the case where two peak-locs have same
        % frequencies.
        [i2, j2] = deal(i(l2), j(l2));  %第l2个分箱中的第i2个块
        dt = [c{1}(i2), c{2}(j2)]; %第i2个对应坐标
        map(rdt(1,:)==dt(1)&rdt(2,:)==dt(2)) = lbl;%在映射矩阵 map 中标记块（此处可能会有多个块同时被标记为同样的数）
        lbl = lbl+1;
    end
end

map(~PCEmsk)=0; %为0的块重新标记为0
clss = single(unique(map(:),'sorted')); 
[h,c_] = hist(map(:),clss);
lblc = cell(3,numel(c_)); %创建一个3xN的单元数组用来存储块标签,块计数,每个块对应坐标
for i = 1:length(c_)
    lblc(:,i) = [{c_(i)};{h(i)};{unique(rdt(:,map(:)==c_(i)),'rows')'}]; %存储块标签,块计数,每个块对应坐标
end


end

