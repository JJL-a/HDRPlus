function [DET,DETd,scale,PCEmax] = CameraID_HDR(I,W,F,Par)
%%% �Copyright DDELab, SUNY Binghamton                      %%%   1.0204
[maxscale, start_search_at] = deal(Par.scalerange(1),Par.scalerange(2));  % 0.9  1.02   0.002
fig = 0; FAR=0.001; figurename = 'ImageScaledPosition.png';
scalestep = Par.scalestep;

Ix = single(rgb2gray(I));

[M0,N0]=size(W);
sizeRP = size(F); 
%生成一个从 1/start_search_at 到 1/maxscale 之间的数值序列
scale_range = 1/start_search_at : scalestep : 1/maxscale;  % proportional steps; 1 means no scaling
if scale_range(end)~=(1/maxscale), scale_range = [scale_range,(1/maxscale)]; end
if isempty(scale_range), error('Par.scalerange must be increasing; [lower,higher]'); end
%>>> Run the coarse search <<<%
DET = ScaleCropSearch(W,Par,scale_range,fig);%在scale_range范围内找到最大PCE
% DET = ScaleCropSearch(Ix,F,W,Par,scale_range,fig);

DET.sizeRP = sizeRP;

%~
% Fine search around the just found peak 
%     if maxscale>DET.scale,  
%         aux=maxscale; maxscale=DET.scale; DET.scale=aux; 
%     end
ind = find(scale_range==DET.scale);%最大PCE对应第几个scale
%DET.scale 前一个scale
scale_before_peak = scale_range(max(1,ind-1));
%DET.scale 后一个scale
scale_after_peak = scale_range(min(ind+1,length(scale_range))); 

sfrom = DET.scale+(scale_before_peak-DET.scale)*6/10;  %根据初步找到的scale和它的前一个创造sfrom
sto = DET.scale-(DET.scale-scale_after_peak)*6/10; %根据初步找到的scale和它的后一个创造sto
if sfrom<sto, aux=sfrom; sfrom=sto; sto=aux; end % start_search_at was empty (scanned image)  %sfrom和sto交换

% fine_scale_range = (sfrom,sto);
%通过缩放参数(sfrom,sto)对图像的长宽进行缩放，找缩放后是否会超出原尺寸
% 如果存在超出的部分，删除对应的Nrange和Mrange（缩放后的长宽）
if M0<N0   %如果W是竖着 
    Nrange = round(N0/sfrom):round(N0/sto);
    Mrange = round(Nrange*M0/N0);
    over = find(Nrange>sizeRP(2));
    if ~isempty(over)
        fprintf('Got over with Nrange. \n');
        Nrange(over)=[];  Mrange(over)=[];
    end
    scale_range_detail = N0./Nrange;
else   %如果W是横着
    Mrange = round(M0/sfrom):round(M0/sto);   %步长为1.以D18\IMG_20240914_160519为例.[3469,3470,3471,3472,3473,3474,3475,3476,3477]
    Nrange = round(Mrange*N0/M0);
    over = find(Mrange>sizeRP(1));
    if ~isempty(over)
        fprintf('Got over with Mrange. \n');
        Nrange(over)=[];  Mrange(over)=[];
    end
    scale_range_detail = M0./Mrange;
end
range_detail = [Mrange;Nrange];

%>>> Realize the detailed search <<<%
% DETd = ScaleCropSearch(Ix,W,F,Par,range_detail,fig);%以图像的长宽找最大值PCE对应scale

DETd = ScaleCropSearch(W,Par,range_detail,fig);

%输出的时候又变回去了   1/scale
if DETd.PCE > DET.PCE,
    scale = 1/DETd.scale;
    PCEmax = DETd.PCE;
else
    scale = 1/DET.scale;
    PCEmax = DET.PCE;
end

if fig
    % Show all PCE values in the entire search
    %     figure,plot(DET.scale_range,DET.PCEi,'.'), xlabel('scaling factor'), ylabel('PCE') 
    %     hold on, plot(scale_range_detail,DETd.PCEi,'.r'), hold off

    search_dim = GetSearchDim([M0,N0],sizeRP,scale_range,range_detail);
    DET.search_dim = search_dim;
    DET.PCEth = PCEfromFA(FAR,DET.search_dim);          % threshold for PCE given the FAR
    if DETd.pvalue*search_dim < FAR                     % if being below probability of false acceptance
        % Show the cropping position in the image
        showscaling = 600/sizeRP(1);                 	% 600 pixels figure height
        Show = 210*zeros([round(sizeRP*showscaling),size(X,3)],'uint8');
        ulc = floor((DETd.upperleft_cropped_out-1)*showscaling)+1;
        lrc = ulc-1 + floor(DET.dim*showscaling);
        Xr = imresize(X,lrc-ulc+1,'nearest');  
        Show(ulc(1):lrc(1), ulc(2):lrc(2),:) = Xr;    	% show the cropped area as the image
        figure, imshow(Show);
        saveas(gcf,figurename,'png')
    end
end

%~
% 
% scriptName = mfilename; % 获取当前脚本的名称
% 
% % 定义保存工作区变量的文件名
% saveFileName = fullfile('E:\HDR\XiaomiHDRout\middle', Par.camN,Par.imgName,[scriptName '_workspace.mat']);
%     if ~exist(fileparts(saveFileName), 'dir')
%         mkdir(fileparts(saveFileName));
%     end
% % 保存所有工作区变量到文件
% save(saveFileName);

end

%---------------------- functions ---------------------
% function DET = ScaleCropSearch(Ix0,F,ImNoise0,Par,scale_range,fig)
function DET = ScaleCropSearch(ImNoise0,Par,scale_range,fig)
% the search in a given range of scaling factors
% DET    detected parameters

PCEi = NaN;
[M0,N0,three]=size(ImNoise0);
if size(scale_range,1)==1
    scale_range_detail = scale_range;
elseif size(scale_range,1)==2
    if M0<N0
        scale_range_detail = N0./scale_range(2,:);
    else
        scale_range_detail = M0./scale_range(1,:);
    end
end



% % === 初始化绘图 ===
% if ~fig
%     % 创建一个新图窗（避免覆盖上次结果）
%     figH = figure('Name', 'Scaling Factor vs PCE', 'NumberTitle', 'off', 'Visible', 'on');
%     clf; % 清空当前图窗内容，防止残留
%     hold on;
%     xlabel('Scaling Factor');
%     ylabel('PCE');
%     title('Scaling Factor vs PCE - Real-Time Search');
%     grid on;
%     box on;
% else
%     figH = [];
% end


%SeeProgress(1); 
if fig, figure, xlabel('Scaling factor'), ylabel('PCE'),end

 i=0;     DET.PCE=0; DET.scale=0;
for scaling = scale_range(1,:)      %在 scale_range 向量的所有元素上进行迭代，在每次迭代中，当前的元素将被赋值给变量 scaling
    i=i+1; 
%     fprintf('All specified files have been modified.%d\n',i);
        %SeeProgress(round(scaling*1000)); 
    if size(scale_range,1)==1             	% the case of coarse search  检查变量 scale_range 是否是一维向量
        ImNoise = imresize(ImNoise0,1/scaling,'nearest');   % 'nearest neighbor' interpolation method works best
%         Ix = imresize(Ix0,1/scaling,'nearest');
    else                                	% dimensions listed in scale_range parameter
        ImNoise = imresize(ImNoise0,[scale_range(1,i),scale_range(2,i)],'nearest'); 
%         Ix = imresize(Ix0,[scale_range(1,i),scale_range(2,i)],'nearest'); 
    end

%     if isequal(ImNoise, ImNoise0)
%         disp('The matrices are identical.');
%     else
%         disp('The matrices are different.');
%     end
%     

    ImNoise = ImNoise - mean(ImNoise(:));   % make it zero mean before using crosscor1
%逐行逐列去均值
%     ImNoise = ZeroMeanTotal(ImNoise);

    % Pad the image noise with zeros
    [s1,s2] = size(ImNoise); 
    sr = size(Par.Ffft) - size(ImNoise);       % shift range for possible cropping
    if all(sr<=0), 
        ImNoise = ImNoise(1:end+sr(1), 1:end+sr(2));
%         Ix = Ix(1:end+sr(1), 1:end+sr(2));
        C = crosscor1(ImNoise,Par.Ffft,1,[],Par.Fnorm);% cross-correlation surface for the detected scaling factor (the order of arguments is important)
%         C = crosscor1(ImNoise, Ix.*F, 1, [], []); %和PRNU一致
        Peak = PCE(C,-sr);   
    elseif all(sr>0)
        ImNoise = padarray(ImNoise,sr,'post');
%         Ix = padarray(Ix,sr,'post');
        C = crosscor1(ImNoise,Par.Ffft,1,[],Par.Fnorm);% cross-correlation surface for the detected scaling factor (the order of arguments is important)
%         C = crosscor1(ImNoise, Ix.*F, 1, [], []); %和PRNU一致
        Peak = PCE(C,sr);                       % see the comment at DET.upperleft_cropped_out below
    %else, break;
    end
    if Peak.PCE>DET.PCE 
        DET.PCE = Peak.PCE;
% %         DET.upperleft_cropped_out = sr+1-Peak.PeakLocation;   ???
        DET.upperleft_cropped_out = Peak.PeakLocation;
        % The upper left corner of the image is located in DET.upperleft_cropped_out pixel of the original image ([1,1] means no cropping there)
        % Because 0 < DET.upperleft_cropped_out < sr  we have gotten the range for searching for the peak
        DET.imdim = size(ImNoise0);
        DET.dim = [s1,s2];
        if size(scale_range,1)==1%第一次使用缩放参数1，第二次使用图像长宽
            DET.scale = scaling;
        else
            DET.scale = max(size(ImNoise0))/max([s1,s2]);
        end
        DET.pvalue = Peak.pvalue; 
    end

    PCEi(i) = Peak.PCE;


%     % === 实时绘图更新 ===
%     if ~fig
%         % 清除旧曲线，重新绘制（避免重叠）
%         cla;
%         plot(scale_range_detail(1:i), PCEi(1:i), 'b-o', 'MarkerFaceColor', 'b', 'MarkerSize', 4);
%         xlabel('Scaling Factor');
%         ylabel('PCE');
%         title(sprintf('Scaling Factor vs PCE (Current Peak: %.2f)', max(PCEi(1:i))));
%         grid on;
%         box on;
%         drawnow limitrate; % 高效刷新，避免卡顿
%     end


    if i>5 & size(scale_range,1)==1             % if this is not the detailed search
        [maxPCE,imax] = max(PCEi);
        % if the peak is higher than 60 and we are past the peak go to the detailed search
        if maxPCE>60 & imax<i-3 & Peak.PCE<=60
            break
        end
    end
end

% % === 函数退出前：保存最终图像 ===
% if ~fig && ishandle(figH)
%     % 目标目录
%     outputDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\scale_pce';
%     
%     % 检查目录是否存在，如果不存在则创建
%     if ~exist(outputDir, 'dir')
%         mkdir(outputDir);
%     end
%     
%     % 生成唯一文件名（可加时间戳或参数）
%     timestamp = datestr(now, 'yyyymmdd-HHMMSS');
%     outputFigName = fullfile(outputDir, sprintf('PCE_Search_%s.png', timestamp));
%     
%     % 保存高清图像
%     exportgraphics(figH, outputFigName, 'Resolution', 300);
%     fprintf('PCE搜索图像已保存为: %s\n', outputFigName);
%     
%     % 可选：关闭图窗（保留注释可保持图窗打开）
%     % close(figH);
% end


DET.scale_range = scale_range_detail(1:i);
if size(scale_range,1)==2
    DET.scale_range_detail = scale_range_detail;
end
DET.PCEi = PCEi;
end

function search_dim = GetSearchDim(imdim,RPdim,scale_range,detail_range)
% calculation of the number of correlation values the maximum is taken from 
%    when the entire range is searched

search_dim = 0; 
for i=1:length(scale_range)
    m = scale_range(i);
    sdim = floor(imdim(1:2)/m);
    n = prod(RPdim-sdim+1);                 % number of all allowed croppings 
    search_dim = search_dim+n;
end

for i=1:size(detail_range,2)
    sdim = detail_range(:,i)';
    n = prod(RPdim-sdim+1);                 % number of all allowed croppings 
    search_dim = search_dim+n;              % total number
end
end
