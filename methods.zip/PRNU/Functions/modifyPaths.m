function modifyPaths()
    % ����Ҫ�޸ĵ��ļ�Ŀ¼
    dirPath = 'E:\Code\multi_var\CameraFingerprint\Functions';
    
    % ����Ҫ���Һ��滻��·��
    %�к�159 CameraID
% 
% %     oldPath1 = 'E:\HDR\XiaomiHDRout\dot-HDR\';
%     oldPath1 = 'E:\HDR\XiaomiHDRout\dot\';
% %     newPath1 = 'E:\HDR\XiaomiHDRout\dot-HDR-180\';
%     newPath1 = 'E:\HDR\XiaomiHDRout\dot-180\';
%     
% %     oldPath2 = 'E:\HDR\XiaomiHDRout\middle-HDR';
%     oldPath2 = 'E:\HDR\XiaomiHDRout\middle';
% %     newPath2 = 'E:\HDR\XiaomiHDRout\middle-HDR-180';
%     newPath2 = 'E:\HDR\XiaomiHDRout\middle-180';
%     
%     SDR->HDR
% 
%         oldPath1 = 'E:\HDR\XiaomiHDRout\dot\';
%         newPath1 = 'E:\HDR\XiaomiHDRout\dot-HDR\';
% 
%         oldPath2 = 'E:\HDR\XiaomiHDRout\middle';
%         newPath2 = 'E:\HDR\XiaomiHDRout\middle-HDR';



        oldPath1 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\dot-HDR_256\';
        newPath1 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\dot-HDR_256-180\';

        oldPath2 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\middle-HDR_256';
        newPath2 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\middle-HDR_256-180';

       
        oldPath3 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\His-HDR_256';
        newPath3 = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_Pout_onlyPCE_test\His-HDR_256-180';

    % ��ȡĿ¼�����е� .m �ļ�
    files = dir(fullfile(dirPath, '*.m'));
    
    % ���� CameraID.m �ļ�
    cameraIDFile = fullfile(dirPath, 'patchworkOnHDR.m');
    if isfile(cameraIDFile)
        modifyFilePaths(cameraIDFile, oldPath1, newPath1);
        modifyFilePaths(cameraIDFile, oldPath2, newPath2);      
        modifyFilePaths(cameraIDFile, oldPath3, newPath3); 
    end
% 
%     cameraIDFile1 = fullfile(dirPath, 'CameraID_sc1.m');
%     if isfile(cameraIDFile1)
%         modifyFilePaths(cameraIDFile1, oldPath1, newPath1);
%         modifyFilePaths(cameraIDFile1, oldPath2, newPath2);                                                                                                              
%     end
%     
%     % ���� getScalingFromBlocks.m �ļ�
%     scalingFile = fullfile(dirPath, 'getScalingFromBlocks.m');
%     if isfile(scalingFile)
%         modifyFilePaths(scalingFile, oldPath2, newPath2);
%     end
% 
%     scalingFile1 = fullfile(dirPath, 'getScaling_scale1.m');
%     if isfile(scalingFile1)
%         modifyFilePaths(scalingFile1, oldPath2, newPath2);
%     end
%     
%     % ���� DetectByBlocks.m �ļ�
%     detectFile = fullfile(dirPath, 'DetectByBlocks.m');
%     if isfile(detectFile)
%         modifyFilePaths(detectFile, oldPath1, newPath1);
%         modifyFilePaths(detectFile, oldPath2, newPath2); 
%     end
%     
%     % ���� patchworkOnHDR.m �ļ�
%     patchworkFile = fullfile(dirPath, 'patchworkOnHDR.m');
%     if isfile(patchworkFile)
%         modifyFilePaths(patchworkFile, oldPath1, newPath1);
%         modifyFilePaths(patchworkFile, oldPath2, newPath2);
% %         modifyFilePaths(patchworkFile, oldPath3, newPath3);
%     end
    
%     fprintf('All specified files have been modified.\n');
    
    function modifyFilePaths(filePath, oldPath, newPath)
        % ��ȡ�ļ�����
        fileText = fileread(filePath);
        
        % �滻��·��Ϊ��·��
        newText = strrep(fileText, oldPath, newPath);
        
        % ���޸ĺ������д���ļ�
        fid = fopen(filePath, 'w');
        fwrite(fid, newText);
        fclose(fid);
        
        % ����޸���Ϣ
%         fprintf('Modified file: %s\n', filePath);
    end
end
