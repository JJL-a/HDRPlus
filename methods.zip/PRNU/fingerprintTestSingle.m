clear; clc;
% ��ʼ��ʱ
tic;
addpath('Filter','functions');

% % �豸�б�
% devices = {'D01_Xiaomi-Mi5-0','D02_Xiaomi-Mi5-zw','A03_Huawei-P9','D04_Xiao-Note4-kc','D05_Xiao-Note4-lq', ...
%            'D06_Xiao-Note4-wq','D07_Xiao-Note4-yy','D08_HUAWEI_R9','D09_iphone6s','D10_iphone7plus', ...
%            'D11_iphoneSE','D12_P10','D13_RY6_plus_0','D14_RY6_plus_1','D15_LEShi_P3','D16_iPhoneX',...
%            'D17_HUAWEI_mate30pro','D18_HUAWEI_mate30pro','D19_iphone12','D20_iphone12','D21_iphone12',...
%            'D22_oppo reno5','D23_XiaomiCivi4pro','D24_XiaoMi14','D25_OPPO find X3','D26_HUAWEI_nova7',...
%            'D27_HUAWEI_R10L','D28_Xiao-Note3'};
% % ��Ҫ�ü�����ת���豸����
% cropRotateConfig = {
%     'D01', false,  []; 
%     'D02', false,  []; 
%     'D03', false,  []; 
%     'D04', false,  [];
%     'D05', false, [];
%     'D06', false,  [];
%     'D07', false,  [];
%     'D08', false,  [];
%     'D09', false,  [];
%     'D10', false,  [];
%     'D11', false,  [];
%     'D12', false,  [];
%     %'D13', false,  [];
%     'D13', true,  [3968,2976];
%     'D14', true,  [3264,1840];
%     'D15', false,  [];
%     'D16', false,  [];
%     'D17', true,  [3648,2736];
%     'D18', false,  [];
%     'D19', false,  [];
%     'D20', false,  [];    
%     'D21', false,  [];
%     'D22', true,  [4096,3072];
%     'D23', false,  [];
%     'D24', false,  [];
%     'D25', true,  [4096,3072];
%     'D26', false,  [];
%     'D27', false,  [];
%     'D28', true,  [4032,3016];
% 
% };
% 
% % ��ʼ��·��
% datasetDir = 'E:\\HDR\\Xiaomi-New\\';

% �豸�б�
devices = {'A01_GioneeS55','A02_Huawei-P8', 'A03_Huawei-Honor9', 'A04_Huawei-P10', 'A05_Hwawie-MatePro10', ...
              'A06_Huawei-Y5', 'A07_Galaxy-S7', 'A08_Galaxy-S7', 'A09_Galaxy-Note5', ...
              'A10_Galaxy-J7', 'A11_Xiaomi5', 'A12_Huawei-RY6', 'A13_Huawei-RY6', ...
              'A14_Xiaomi-5A', 'A15_Xiaom-3', 'A16_OnePlus-3t', 'A17_AsusZenfone-2', ...
              'I01_iphone8', 'I02_iphonese', 'I03_iphone7', 'I04_iPad-Air', ...
              'I05_iphone6', 'I06_iphone-5S'};

% ��ȡ˳��
extractOrder = {
    'A01', 'A02'; 'A02', 'A01'; 'A03', 'A17'; 'A04', 'A05'; 'A05', 'A04';
    'A06', 'A12'; 'A07', 'A10'; 'A08', 'A14'; 'A09', 'A15'; 'A10', 'A07';
    'A11', 'A16'; 'A12', 'A13'; 'A13', 'A12'; 'A14', 'A08'; 'A15', 'A09';
    'A16', 'A10'; 'A17', 'A03'; 'I01', 'I03'; 'I02', 'I03'; 'I03', 'I02';
    'I04', 'A03'; 'I05', 'I06'; 'I06', 'I05'
};

% ��Ҫ�ü�����ת���豸����
cropRotateConfig = {
    'A01', true, true, [4160,3120]; % �ü�Ϊ4160 x 3120����ת
    'A02', true, false,[3968,2976]; % ���ü�������ת
    'A03', true, false, [3264,1836]; % ���ü�������ת
    'A04',false,false,[];
    'A05',false,false,[];
    'A06',false,false,[];
    'A07',false,false,[];
    'A08',false,false,[];
    'A09',true, false, [4608,2592];
    'A10',true, false, [4032,3024];
    'A11',false,true,[];
    'A12',false,true,[];
    'A13',false,true,[];
    'A14',true, false, [4032,2268];
    'A15',false, false,[];
    'A16',true, false, [4128,3096];
    'A17',false, false,[];
    'I01',false,true,[];
    'I02',false, false,[];
    'I03',false, false,[];
    'I04',true, false, [2592,1840];
    'I05',false,true,[];
    'I06',false, false,[];   
};

% ��ʼ��·��
datasetDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDR-Dataset\\';
trainSizeA16 = 47;


% for i = 27:length(devices)
% for i = [9:10,16,21]
for i = 14
% for i = [1,4:5,7:23]
    posDevice = devices{i};
    posD = extractOrder{i, 1};

    % ��ȡ�ü�����ת����
    configIdx = find(strcmp(cropRotateConfig(:, 1), posDevice(1:3)));
    if ~isempty(configIdx)
        doCrop = cropRotateConfig{configIdx, 2};
        cropSize = cropRotateConfig{configIdx, 4};
    else
        doCrop = false;        
        cropSize = [];
    end

     % �ҵ���Ӧ�豸·��
    deviceIndex = find(startsWith(devices, posDevice));
    fingerprintPath = fullfile(datasetDir, devices{deviceIndex}, 'FLAT', 'SDR_FLAT');
    
    % ��ȡѵ����·��
    trainFiles = dir(fullfile(fingerprintPath, [posD, '_SDR_FLAT_*.jpg']));
    trainPaths = {trainFiles(~contains({trainFiles.name}, '._')).name};
    
    if strcmp(posD, 'A16')
        trainPaths = fullfile(fingerprintPath, trainPaths(1:trainSizeA16));
    else
        trainPaths = fullfile(fingerprintPath, trainPaths(1:50));
    end

    
% %     % �ҵ���Ӧ�豸·��
% %     fingerprintPath = fullfile(datasetDir, posDevice, 'SDR-FLAT');
% %     
% %     % ��ȡѵ����·��
% %     
% %     trainFiles = dir(fullfile(fingerprintPath, '*.jpg'));
% 
% %     % ���û���ҵ�ѵ���ļ�����������豸
% %     if isempty(trainPaths)
% %         fprintf('�豸 %s û���ҵ�ͼ���ļ����������豸��\n', posDevice);
% %         continue;
% %     end
% 
% %     % ȡǰ40��ͼ���ļ�
% %     numTrainFiles = min(40, length(trainFiles));
% %     trainPaths = fullfile(fingerprintPath, {trainFiles(1:numTrainFiles).name});

    % ���豸��ȡָ��
    RP = getFingerprint1(trainPaths,[], doCrop, cropSize);
    RP = rgb2gray1(RP);
    sigmaRP = std2(RP);
    Fingerprint = WienerInDFT(RP, sigmaRP);
    
    % ����RP��Fingerprint
%     savePath = fullfile('E:\\HDR\\Xiaomi-New-out\\fingerprintSingle', posDevice, 'fingerprint.mat');
    savePath = fullfile('E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\HDR_fingerpirnt', devices{deviceIndex}, 'fingerprint.mat');
    
    if ~exist(fileparts(savePath), 'dir')
        mkdir(fileparts(savePath));
    end
    save(savePath, 'RP', 'Fingerprint');
    
    % ������ʱ
    elapsedTime = toc;
    % ��ʾ����ʱ��
    fprintf('�豸 %s ��������ʱ��: %f ��\n', posDevice, elapsedTime);
end