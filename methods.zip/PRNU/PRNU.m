% 清除环境变量
clear; clc;
% 开始计时
tic;

addpath('Filter', 'functions');

Par = [];

% % % % 初始化路径
datasetDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDR-Dataset\\';
fingerprintDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\HDR_fingerpirnt\\';
% outputAllpathDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\DHIF_Pout_onlyPCE_test\\testWiener\\allpath-HDR(orin)\\';
% outputROCDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\DHIF_Pout_onlyPCE_test\\testWiener\\ROC-HDR(orin)\\';
% outputPCEDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\DHIF_Pout_onlyPCE_test\\testWiener\\PCE-HDR(orin)\\';
% outputResultDir = 'E:\\1\\post\\paper\\PRNU-sourcecode\\HDRcode\\DHIF_Pout_onlyPCE_test\\testWiener\\result-HDR(orin)\\';

% datasetDir = 'E:\HDR\Xiaomi-New\';
% fingerprintDir = 'E:\HDR\Xiaomi-New-out\fingerprintSingle\';
outputAllpathDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\5\allpath-HDR\';
outputROCDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\5\ROC-HDR\';
outputPCEDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\5\PCE-HDR\';
outputResultDir = 'E:\1\post\paper\PRNU-sourcecode\HDRcode\DHIF_HDRPout\test_D081727\5\result-HDR\';

if ~exist(outputAllpathDir, 'dir')
    mkdir(outputAllpathDir);
end
if ~exist(outputROCDir, 'dir')
    mkdir(outputROCDir);
end
if ~exist(outputPCEDir, 'dir')
    mkdir(outputPCEDir);
end
if ~exist(outputResultDir, 'dir')
    mkdir(outputResultDir);
end


% % % 设备列表
devices = {'A01_GioneeS55','A02_Huawei-P8', 'A03_Huawei-Honor9', 'A04_Huawei-P10', 'A05_Hwawie-MatePro10', ...
              'A06_Huawei-Y5', 'A07_Galaxy-S7', 'A08_Galaxy-S7', 'A09_Galaxy-Note5', ...
              'A10_Galaxy-J7', 'A11_Xiaomi5', 'A12_Huawei-RY6', 'A13_Huawei-RY6', ...
              'A14_Xiaomi-5A', 'A15_Xiaom-3', 'A16_OnePlus-3t', 'A17_AsusZenfone-2', ...
              'I01_iphone8', 'I02_iphonese', 'I03_iphone7', 'I04_iPad-Air', ...
              'I05_iphone6', 'I06_iphone-5S'};

% % % 提取顺序
extractOrder = {
    'A01', 'A02'; 'A02', 'A04'; 'A03', 'A17'; 'A04', 'A05'; 'A05'  , 'A04';
    'A06', 'A12'; 'A07', 'A10'; 'A08', 'A14'; 'A09', 'A15'; 'A10', 'A07';
    'A11', 'A16'; 'A12', 'A13'; 'A13', 'A12'; 'A14', 'A08'; 'A15', 'A09';
    'A16', 'A10'; 'A17', 'A03'; 'I01', 'I03'; 'I02', 'I03'; 'I03', 'I02';
    'I04', 'A03'; 'I05', 'I06'; 'I06', 'I05'
};

% sampleSize = [300, 300, 130, 130, 120, 120, 120, 300, 300, 300, 300, 300, 120, 300, 300,120,120,120,120,120,120,120,120,120,120,120,120,120,120,120];
sampleSize = [15,15, 20,20,20,20,20,20, 20];
% sampleSize = 15;

% 保存所有ROC曲线的数据
all_fpr = [];
all_tpr = [];

% 保存阈值为60时的FPR和TPR
all_fpr_threshold = [];
all_tpr_threshold = [];

% for k = 1:length(extractOrder)
% for k = [8,17,27]   1:11,17:21,23:26
for k = 1
    loop_start = tic; % 开始单次循环计时
    
    posDevice = extractOrder{k, 1};
    negDevice = extractOrder{k, 2};
    
    % 找到对应设备索引
    posIndex = find(contains(devices, posDevice));
    negIndex = find(contains(devices, negDevice));
    
    % 确定样本大小
    posSampleSize = sampleSize(posIndex);
    negSampleSize = posSampleSize;
    
%     posSampleSize = sampleSize;
%     negSampleSize = sampleSize;

    % 从文件加载指纹
    fingerprintFile = fullfile(fingerprintDir, devices{posIndex}, 'fingerprint.mat');
    if exist(fingerprintFile, 'file')
        load(fingerprintFile, 'RP');
        Fingerprint = RP;
    else
        error('指纹文件 %s 不存在', fingerprintFile);
    end
    %从HDRPRNU添加进来的
%     Fingerprint = NoiseExtractInDFT(Fingerprint);

    [F_Resolution_x, F_Resolution_y] = size(Fingerprint);
    
    % 初始化正负样本路径
    positiveSamples = [];
    negativeSamples = [];
    
    % 提取正样本
    testDirPositive = fullfile(datasetDir, devices{posIndex}, 'NAT','HDR_HAND');
    testFilesPositive = dir(fullfile(testDirPositive, '*.jpg'));
    testPathsPositive = {testFilesPositive(~contains({testFilesPositive.name}, '._')).name};
    testPathsPositive = fullfile(testDirPositive, testPathsPositive(1:posSampleSize));
    positiveSamples = [positiveSamples, testPathsPositive]; %#ok<AGROW>
    
    % 提取负样本
    testDirNegative = fullfile(datasetDir, devices{negIndex}, 'NAT','HDR_HAND');
    testFilesNegative = dir(fullfile(testDirNegative, '*.jpg'));
    testPathsNegative = {testFilesNegative(~contains({testFilesNegative.name}, '._')).name};
    testPathsNegative = fullfile(testDirNegative, testPathsNegative(1:negSampleSize));
    negativeSamples = [negativeSamples, testPathsNegative]; %#ok<AGROW>
%     


%      % 提取正样本
%     testDirPositive = fullfile(datasetDir, devices{posIndex}, 'HDR-NAT');
%     testFilesPositive = dir(fullfile(testDirPositive, '*.jpg'));
%     testPathsPositive = {testFilesPositive(~contains({testFilesPositive.name}, '._')).name};
%     testPathsPositive = fullfile(testDirPositive, testPathsPositive(1:posSampleSize));
%     positiveSamples = [positiveSamples, testPathsPositive]; %#ok<AGROW>
%     
%     % 提取负样本
%     testDirNegative = fullfile(datasetDir, devices{negIndex}, 'HDR-NAT');
%     testFilesNegative = dir(fullfile(testDirNegative, '*.jpg'));
%     testPathsNegative = {testFilesNegative(~contains({testFilesNegative.name}, '._')).name};
%     testPathsNegative = fullfile(testDirNegative, testPathsNegative(1:negSampleSize));
%     negativeSamples = [negativeSamples, testPathsNegative]; %#ok<AGROW>


     % Combine positive and negative samples
    allPaths = [positiveSamples, negativeSamples];
    % 保存 allPaths 到 .mat 文件
    save(fullfile(outputAllpathDir,[posDevice '-allPaths.mat']), 'allPaths');

    % 初始化gt和cc矩阵
    numTests = length(positiveSamples) + length(negativeSamples);
    gt = [true(1, length(positiveSamples)), false(1, length(negativeSamples))];
    cc = zeros(1, numTests);
    PCE_values = zeros(1, length(allPaths));

%     pce_all = zeros(2, numTests); % 用于保存两次旋转的PCE值
    pce1 = zeros(1, numTests);
    pce2 = zeros(1, numTests);

%     % 计算每张测试图像和指纹的PCE
%     indexPositive = 1;
%     indexNegative = 1;
    
    for i = 1:length(allPaths)
%     for i = 1:3
%      for i = 21:23
        img = imread(allPaths{i});
        [~, Par.imgName, ext] = fileparts(allPaths{i});
        cameraName = strsplit(fingerprintFile, filesep);
        if length(cameraName) > 1, cameraName = cameraName{end-1}; else, cameraName = 'Camera'; end

        [img_resolution_x, img_resolution_y, ~] = size(img);  %x是宽（高）  y是长
        if img_resolution_x < img_resolution_y
            img = imrotate(img, 90);
        end
        if img_resolution_x ~= F_Resolution_x || img_resolution_y ~= F_Resolution_y
%             img = imcrop(img, [1, 1, F_Resolution_y - 1, F_Resolution_x - 1]);
              img = imcropmiddle(img, [  F_Resolution_x,F_Resolution_y]);  % 
%             
        end
        pce1(i) = computePCE(img, Fingerprint,Par,cameraName, F_Resolution_y);
        
        modifyPaths();

        img_rot = imrotate(img, 180);
        pce2(i) = computePCE(img_rot, Fingerprint,Par,cameraName, F_Resolution_y);
%         pce_all(:, i) = [pce1; pce2];
        cc(i) = max(pce1(i), pce2(i));

        modifyPathsBack();

    end


    % 保存cc和gt矩阵
    cc_gt_Dir = fullfile(outputPCEDir, [posDevice, '-', negDevice]);
    if ~exist(cc_gt_Dir, 'dir')
        mkdir(cc_gt_Dir);
    end
    save(fullfile(cc_gt_Dir, 'cc.mat'), 'cc');
    save(fullfile(cc_gt_Dir, 'gt.mat'), 'gt');
%     save(fullfile(cc_gt_Dir, 'pce_all.mat'), 'pce_all');  % 保存pce_all矩阵
    save(fullfile(cc_gt_Dir, 'pce1.mat'), 'pce1'); 
    save(fullfile(cc_gt_Dir, 'pce2.mat'), 'pce2'); 

    % 计算ROC和AUC
    [fpr, tpr, th] = perfcurve(gt, cc, true);
    auc_score = trapz(fpr, tpr);

    % 累加ROC数据
    all_fpr = [all_fpr; fpr]; %#ok<AGROW>
    all_tpr = [all_tpr; tpr]; %#ok<AGROW>

    % 画ROC曲线并保存
    figure('Visible', 'off');
    lw = 2;
    plot(fpr, tpr, 'Color', [1, 0.549, 0], 'LineWidth', lw);  % 使用 RGB 值指定深橙色
    hold on;
    plot([0, 1], [0, 1], 'Color', 'b', 'LineWidth', lw, 'LineStyle', '--');  % 使用蓝色
    hold off;
    xlim([0.0, 1.0]);
    ylim([0.0, 1.05]);
    xlabel('False Positive Rate');
    ylabel('True Positive Rate');
    title(['ROC Curve for ', posDevice, ' vs ', negDevice]);
    legend('ROC curve', 'Location', 'southeast');
    set(gca, 'TickDir', 'in');  
    saveas(gcf, fullfile(outputROCDir, [posDevice, '-', negDevice, '_ROC.jpg']));
    close(gcf);

    % 计算阈值为60时的FPR和TPR
    threshold = 60;
    fpr_threshold = sum((cc >= threshold) & (gt == 0)) / sum(gt == 0);
    tpr_threshold = sum((cc >= threshold) & (gt == 1)) / sum(gt == 1);

    all_fpr_threshold = [all_fpr_threshold, fpr_threshold];
    all_tpr_threshold = [all_tpr_threshold, tpr_threshold];

    % 保存每次循环的结果到文件
    resultFileName = fullfile(outputResultDir, [posDevice, '-', negDevice, '_result.mat']);
    save(resultFileName, 'posDevice', 'negDevice', 'auc_score', 'tpr_threshold', 'fpr_threshold');


    fprintf('Device: %s\n', posDevice);
    fprintf('AUC: %f\n', auc_score);
    fprintf('FPR at threshold: %f\n', fpr_threshold);
    fprintf('TPR at threshold: %f\n', tpr_threshold);

    loop_elapsedTime = toc(loop_start); % 计算单次循环时间
    fprintf('Loop %d elapsed time: %f seconds\n', k, loop_elapsedTime);
end


% 结束计时
elapsedTime = toc;
% 显示运行时间
fprintf('代码运行总时间: %f 秒\n', elapsedTime);

% 从图像矩阵中提取噪声的函数
function Noisex = NoiseExtractFromImageMatrix(img, qmf)
    tempFileName = [tempname, '.png'];
    % 临时存图像
    imwrite(img, tempFileName);    
    % 使用原函数提取噪声
    Noisex = NoiseExtractFromImage(tempFileName, qmf);    
    delete(tempFileName);
end

% 计算PCE的函数
function pce = computePCE(img, Fingerprint, F_Resolution_y)
    Noisex = NoiseExtractFromImageMatrix(img, 2);
    Noisex = WienerInDFT(Noisex, std2(Noisex));
    Ix = double(rgb2gray(img));
    C = crosscorr(Noisex, Ix .* Fingerprint);
    spce = PCE(C);
    pce = spce.PCE;


end

