function X = imcropmiddle_1(X, sizeout, preference)
% 从一个给定的图像矩阵 X 中裁剪出中间的一部分，裁剪后的大小由 sizeout 参数指定。
% function X = imcropmiddle(X, sizeout, preference) crops the middle portion of a given size
% X         image matrix
% sizeout   size of the output image

% 将 preference 设置为默认值 'SE'（代表“东南”，或右下角）
if nargin < 3, preference = 'SE'; end
% 如果 sizeout 参数提供了超过两个元素（可能包括颜色通道）
% 这行代码将其限制为前两个元素，即仅考虑图像的行和列大小。
if length(sizeout) > 2, sizeout = sizeout(1:2); end

% 获取原始图像 X 的尺寸
[M, N, three] = size(X);

% 确保 sizeout 不超过原图尺寸
sizeout = min([[M, N]; sizeout]); % 重新确保裁剪尺寸不会超过原图

% 计算裁剪区域的起始和结束坐标
switch preference
    case 'NW' % 左上角
        M0 = floor((M - sizeout(1)) / 2);
        N0 = floor((N - sizeout(2)) / 2);
    case 'SW' % 左下角
        M0 = ceil((M - sizeout(1)) / 2);
        N0 = floor((N - sizeout(2)) / 2);
    case 'NE' % 右上角
        M0 = floor((M - sizeout(1)) / 2);
        N0 = ceil((N - sizeout(2)) / 2);
    case 'SE' % 右下角
        M0 = ceil((M - sizeout(1)) / 2);
        N0 = ceil((N - sizeout(2)) / 2);
end

% 确保裁剪区域在图像范围内
M1 = M0 + sizeout(1);
N1 = N0 + sizeout(2);

% 处理边界情况
M0 = max(M0, 0);
N0 = max(N0, 0);
M1 = min(M1, M);
N1 = min(N1, N);

% 裁剪图像
X = X(M0 + 1:M1, N0 + 1:N1, :);
